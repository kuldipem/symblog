<?php

namespace Blogger\TaskBundle;

use Symfony\Component\HttpKernel\Bundle\Bundle;

class BloggerTaskBundle extends Bundle
{
}
