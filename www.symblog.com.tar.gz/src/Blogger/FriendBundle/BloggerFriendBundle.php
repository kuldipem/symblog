<?php

namespace Blogger\FriendBundle;

use Symfony\Component\HttpKernel\Bundle\Bundle;

class BloggerFriendBundle extends Bundle
{
}
